# Connector_PCBEdge.pretty
This library contains PCB edge connectors

---

Scripts are used to generate the following connectors:
- Samtec MECF

Script details
- authors: Dominik Baack, Poeschl Rene, Jan W. Krieger, Oliver Walters, evanshultz, Thomas Pointhuber (see git log for details)
- script location: https://github.com/pointhi/kicad-footprint-generator/tree/master/scripts/Connector/
- used config file (where applicable): config_KLCv3.0.yaml
- python version: 3.6.2
